
public class Zombie_01 {



	int health = 100;
	
	public void bite() {
		System.out.println("BITE!")
	}
	
	public void hurtMe() {
		health = health -1;
	}
	
}